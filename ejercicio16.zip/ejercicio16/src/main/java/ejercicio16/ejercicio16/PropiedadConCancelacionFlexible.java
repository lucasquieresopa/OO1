package ejercicio16.ejercicio16;

import java.util.ArrayList;

public class PropiedadConCancelacionFlexible extends Propiedad{
	
	
	public PropiedadConCancelacionFlexible (Propiedad propiedad) {
		
	}
	
	public Double calcularReembolso() {
		if(this.)
	}
}
