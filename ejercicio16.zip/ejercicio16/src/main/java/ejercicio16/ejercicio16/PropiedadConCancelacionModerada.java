package ejercicio16.ejercicio16;

public class PropiedadConCancelacionModerada extends Propiedad{

	public Double calcularReembolso() {
		
	}
}
