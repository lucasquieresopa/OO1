package ejercicio16.ejercicio16;

import java.util.ArrayList;

public class Usuario {
	private String nombre;
	private String direccion;
	private String dni;
	private ArrayList<Propiedad> propiedadesEnAlquiler;
	private ArrayList<Reserva> reservasActuales;
	private ArrayList<Reserva> historialDeAlquileres;


	public Usuario(String nombre, String direccion, String dni) {
		this.nombre=nombre;
		this.direccion=direccion;
		this.dni=dni;
		
		this.propiedadesEnAlquiler = new ArrayList<Propiedad>();
		this.reservasActuales = new ArrayList<Reserva>();
		this.historialDeAlquileres = new ArrayList<Reserva>();
		
	}
	public Usuario() {
		this.propiedadesEnAlquiler = new ArrayList<Propiedad>();
		this.reservasActuales = new ArrayList<Reserva>();
		this.historialDeAlquileres = new ArrayList<Reserva>();
	}
	public void agregarReservaAUsuario(Reserva reservaAAgregar) {
		this.reservasActuales.add(reservaAAgregar);
		this.agregarReservaAHistorial(reservaAAgregar);
	}
	
	public ArrayList<Reserva> getReservas(){
		return this.reservasActuales;
	}
	
	private void agregarReservaAHistorial(Reserva reserva) {
		this.historialDeAlquileres.add(reserva);
	}
	
	public Double calcularIngresosEntreFechas(DateLapse periodo) {
		return this.propiedadesEnAlquiler.stream()
				.mapToDouble(propiedad -> propiedad.getGananciasEntreFecha(periodo))
				.sum();
	}
	
	public void agregarPropiedad(Propiedad nuevaPropiedad) {
		this.propiedadesEnAlquiler.add(nuevaPropiedad);
	}
}
