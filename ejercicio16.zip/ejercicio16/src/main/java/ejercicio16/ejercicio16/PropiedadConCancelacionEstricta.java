package ejercicio16.ejercicio16;

public class PropiedadConCancelacionEstricta extends Propiedad{

	public Double calcularReembolso() {
		
	}
}
