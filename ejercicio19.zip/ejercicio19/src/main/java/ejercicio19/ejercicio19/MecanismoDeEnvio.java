package ejercicio19.ejercicio19;

public interface MecanismoDeEnvio {
	public abstract Double devolverAdicional(String dir1, String dir2);
}
