package ejercicio19.ejercicio19;

public interface FormaDePago {
	public abstract Double devolverIncremento();
}
