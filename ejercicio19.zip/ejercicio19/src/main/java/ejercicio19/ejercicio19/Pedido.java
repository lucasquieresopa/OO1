package ejercicio19.ejercicio19;

public class Pedido {
	private Cliente cliente;
	private Producto producto;
	private FormaDePago fdp;
	private MecanismoDeEnvio mde;
	private Integer cantidad;
	
	public Pedido(Cliente cliente, Producto producto, FormaDePago fdp,
			MecanismoDeEnvio mde, Integer cantidad) {
		this.cliente=cliente;
		this.producto=producto;
		this.fdp=fdp;
		this.mde=mde;
		this.cantidad=cantidad;
	}
	
	public Double calcularCosto() {
		return ((this.producto.getPrecio() * this.cantidad * this.fdp.devolverIncremento())
				+ this.mde.devolverAdicional(this.cliente.getDireccion(), this.producto.getDireccionDeVendedor()));
	}
	
}
