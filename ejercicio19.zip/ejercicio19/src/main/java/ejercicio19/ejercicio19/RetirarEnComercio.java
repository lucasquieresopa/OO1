package ejercicio19.ejercicio19;

public class RetirarEnComercio implements MecanismoDeEnvio{
	public Double devolverAdicional(String dir1, String dir2) {
		return 0.0;
	}
}
