package ejercicio19.ejercicio19;

public class ExpressADomicilio implements MecanismoDeEnvio{
	private Mapa mapa;
	
	public Double devolverAdicional(String dir1, String dir2) {
		Mapa mapa = new Mapa(dir1, dir2);
		this.mapa = mapa;
		return 0.5 * this.mapa.distanciaEntre(dir1, dir2);
	}
	
}
