package ejercicio19.ejercicio19;

public class AlContado implements FormaDePago{
	public Double devolverIncremento() {
		return 1.0;
	}
}
