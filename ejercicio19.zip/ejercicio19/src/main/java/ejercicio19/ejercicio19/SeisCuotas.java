package ejercicio19.ejercicio19;

public class SeisCuotas implements FormaDePago{
	public Double devolverIncremento() {
		return 1.2;
	}
}
