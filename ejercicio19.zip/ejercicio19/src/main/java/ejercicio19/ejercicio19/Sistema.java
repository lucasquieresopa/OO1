package ejercicio19.ejercicio19;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class Sistema {

	private List<Vendedor> vendedores;
	private List<Cliente> clientes;
	private List<Producto> productos;
	private List<Pedido> pedidos;
	
	public Sistema() {
		this.vendedores = new ArrayList<Vendedor>();
		this.clientes = new ArrayList<Cliente>();
		this.productos = new ArrayList<Producto>();
		this.pedidos = new ArrayList<Pedido>();
	}
	
	public Vendedor registrarVendedor(String nombre, String direccion) {
		Vendedor nuevoVendedor = new Vendedor(nombre, direccion);
		this.vendedores.add(nuevoVendedor);
		return nuevoVendedor;
	}
	
	public Vendedor buscarVendedor(String nombre) {
		return this.vendedores.stream()
				.filter(vendedor -> vendedor.getNombre().equals(nombre))
				.findAny().orElse(null);
	}
	
	public Cliente registrarCliente(String nombre, String direccion) {
		Cliente nuevoCliente = new Cliente(nombre, direccion);
		this.clientes.add(nuevoCliente);
		return nuevoCliente;
	}
	
	public Cliente buscarCliente(String nombre) {
		return this.clientes.stream()
				.filter(cliente -> cliente.getNombre().equals(nombre))
				.findAny().orElse(null);
	}
	
	public Producto ponerProductoEnVenta(String nombre, String descripcion, 
			Double precio, Integer unidadesDisp, Vendedor vendedor) {
		Producto nuevoProducto = new Producto(nombre, descripcion, precio, unidadesDisp, vendedor);
		this.productos.add(nuevoProducto);
		return nuevoProducto;
	}
	
	public List<Producto> buscarProducto(String nombre){
		return this.productos.stream()
				.filter(producto -> producto.getNombre().equals(nombre))
				.collect(Collectors.toList());
	}
	
	public void crearPedido(Cliente cliente, Producto producto, FormaDePago fdp, 
			MecanismoDeEnvio mde, Integer cantidad) {
		if(producto.getUnidades() >= cantidad) {
			this.pedidos.add(new Pedido(cliente, producto, fdp, mde, cantidad));
			producto.actualizarUnidades(cantidad);
		}
	}
	
	public Double calcularCostoTotalDePedido(Pedido pedido) {
		return pedido.calcularCosto();
	}
	
	
	
	//Metodos agregados para hacer tests
	public List<Vendedor> getVendedores(){
		return this.vendedores;
	}
	
	public List<Cliente> getClientes(){
		return this.clientes;
	}
	
	public List<Producto> getProductos(){
		return this.productos;
	}
	
	public List<Pedido> getPedidos(){
		return this.pedidos;
	}
	
	public Pedido crearPedido1(Cliente cliente, Producto producto, FormaDePago fdp, 
			MecanismoDeEnvio mde, Integer cantidad) {
		if(producto.getUnidades() >= cantidad) {
			Pedido nuevoPedido = new Pedido(cliente, producto, fdp, mde, cantidad);
			this.pedidos.add(nuevoPedido);
			producto.actualizarUnidades(cantidad);
			return nuevoPedido;
		}
		return null;
	}
	
	
/*
DUDAS:
cuando busco un cliente o un vendedor hago ".FindAny()" cuando el resultado de
del filter me aporta sólo un elemento. Es correcto hacerlo de esa manera?

En el enunciado "Crear pedido" dice "se registra el pedido". ¿Debo guardarlos en una lista de pedidos?

Usar primitivos o wrappers para las variables?

A la hora de implementar el metodo "devolverAdicional()" en cada mecanismo de pago, solo uno utiliza
las dos direcciones para hacer el calculo. Entonces ¿Es correcto enviar a todos las dos direcciones
aunque solo las use una de las tres clases?

¿Es correcto implementar algunos metodos para probar los test, o debo hacer los test con
los metodos ya implementados?

¿Deberia hacer un test para cada clase o uno general para el sistema?

Pedir correccion del diagrama UML


 */
}
