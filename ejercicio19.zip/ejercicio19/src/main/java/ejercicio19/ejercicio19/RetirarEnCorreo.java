package ejercicio19.ejercicio19;

public class RetirarEnCorreo implements MecanismoDeEnvio{

	public Double devolverAdicional(String dir1, String dir2) {
		return 50.0;
	}
}
