package ejercicio19.ejercicio19;

public class Producto {
	private String nombre;
	private String descripcion;
	private Double precio;
	private Integer cantidad;
	private Vendedor vendedor;
	
	public Producto(String nombre, String descripcion, Double precio,
			Integer cantidad, Vendedor vendedor) {
		this.nombre=nombre;
		this.descripcion=descripcion;
		this.precio=precio;
		this.cantidad=cantidad;
		this.vendedor=vendedor;
	}
	
	public String getNombre() {
		return this.nombre;
	}
	
	public void actualizarUnidades(Integer cantidad) {
		this.cantidad=this.cantidad - cantidad;
	}
	
	public Double getPrecio() {
		return this.precio;
	}
	
	public Integer getUnidades() {
		return this.cantidad;
	}
	
	public String getDireccionDeVendedor() {
		return this.vendedor.getDireccion();
	}
}
