package ejercicio19.ejercicio19;

public class Mapa {
	private String dir1;
	private String dir2;

	public Mapa(String dir1, String dir2) {
		this.dir1=dir1;
		this.dir2=dir2;
	}
	
	public Double distanciaEntre(String dir1, String dir2) {
		return 100.0;
	}
}
