package ejercicio19.ejercicio19;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TestSistema {

	private Vendedor v1, v2;
	private Cliente c1, c2;
	private Producto p1, p2;
	private Pedido pedido;
	private Sistema sis;
	private FormaDePago fdp1, fdp2;
	private MecanismoDeEnvio mde1, mde2, mde3;
	
	@BeforeEach
	public void setUp() {
		this.sis = new Sistema();
		
		this.v1 = this.sis.registrarVendedor("Lucas", "Peru 2000");
		this.v2 = this.sis.registrarVendedor("Tomas", "Brasil 80");
		
		this.c1 = this.sis.registrarCliente("Leon", "Mexico 50");
		this.c2 = this.sis.registrarCliente("Diego", "Inglaterra 1986");
		
		this.p1 = this.sis.ponerProductoEnVenta("Jabon", "Blanco", 80.0, 10, this.v1);
		this.p2 = this.sis.ponerProductoEnVenta("Shampo", "Suave", 200.0, 50, this.v2);
		
		this.fdp1 = new AlContado();
		this.fdp2 = new SeisCuotas();
		
		this.mde1 = new RetirarEnComercio();
		this.mde2 = new RetirarEnCorreo();
		this.mde3 = new ExpressADomicilio();
		
		}
	
	@Test
	public void testVendedor() {
		assertEquals(2, this.sis.getVendedores().size());
		assertTrue(this.sis.getVendedores().contains(this.v1));
		assertTrue(this.sis.buscarVendedor("Tomas").equals(this.v2));
	}
	@Test
	public void testCliente() {
		assertEquals(2, this.sis.getClientes().size());
		assertTrue(this.sis.buscarCliente("Diego").equals(this.c2));
	}
	@Test 
	public void testProducto() {
		assertEquals(2, this.sis.getProductos().size());
		assertTrue(this.sis.buscarProducto("Shampo").contains(this.p2));
	}
	@Test
	public void testCrearPedido() {
		this.sis.crearPedido(this.c1, this.p1, fdp1, mde1, 8);
		assertEquals(1, this.sis.getPedidos().size());
		this.sis.crearPedido(this.c1, this.p1, fdp1, mde1, 8);
		assertEquals(1, this.sis.getPedidos().size());
		assertEquals(2, this.p1.getUnidades());
	}
	@Test
	public void testCalcularCosto() {
		this.pedido = this.sis.crearPedido1(this.c1, this.p1, fdp1, mde1, 2);
		assertEquals(160.0, this.sis.calcularCostoTotalDePedido(pedido));
		this.pedido = this.sis.crearPedido1(this.c1, this.p1, fdp2, mde2, 2);
		assertEquals(242.0, this.sis.calcularCostoTotalDePedido(pedido));
		this.pedido = this.sis.crearPedido1(this.c1, this.p1, fdp1, mde3, 2);
		assertEquals(210.0, this.sis.calcularCostoTotalDePedido(pedido));
	}
}
