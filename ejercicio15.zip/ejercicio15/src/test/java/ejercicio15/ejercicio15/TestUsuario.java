package ejercicio15.ejercicio15;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TestUsuario {
	
	
	@BeforeEach
	public void setUp() {
		
	}
	
	@Test
	public void TestCalculoDeIngresos() {
		
	}
}
