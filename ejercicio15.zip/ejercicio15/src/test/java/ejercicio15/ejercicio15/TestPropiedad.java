package ejercicio15.ejercicio15;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TestPropiedad {
	private Propiedad p1, p2;
	private Usuario u1;
	private LocalDate f1 = LocalDate.of(2000, 1, 1);
	private LocalDate f2 = LocalDate.of(2003, 1, 1);
	private LocalDate f3 = LocalDate.of(1998, 1, 1);
	private LocalDate f4 = LocalDate.of(2005, 1, 1);
	
	@BeforeEach
	public void SetUp() {
		this.u1 = new Usuario();
		
		this.p1 = new Propiedad("nombre1", "descripcion1", 100.0,
				"direccion1", this.u1);
		this.p1.agregarReservaAPropiedad(new Reserva(p1, 
				new DateLapse(LocalDate.of(2000, 1, 1), LocalDate.of(2000, 1, 10)), 
				new Usuario()));
		this.p1.agregarReservaAPropiedad(new Reserva(p1, 
				new DateLapse(LocalDate.of(2000, 1, 20), LocalDate.of(1992, 1, 30)), 
				this.u1));

		this.p2 = new Propiedad("nombre2", "descripcion2", 300.0,
				"direccion2", this.u1);
		this.p2.agregarReservaAPropiedad(new Reserva(p2, 
				new DateLapse(LocalDate.of(2000, 1, 10), LocalDate.of(2000, 1, 20)), 
				this.u1));
	}
	
	@Test
	public void TestDisponibilidad() {
		
		assertFalse(p1.Disponibilidad(new DateLapse(f1, f2)));
		assertFalse(p1.Disponibilidad(new DateLapse(f3, f1)));
		assertFalse(p1.Disponibilidad(new DateLapse(f3, f2)));
		assertTrue(p1.Disponibilidad(new DateLapse(f2, f4)));
	}
	
	@Test
	public void TestGananciasDeUnaPropiedadEntrePeriodo() {
		
	}
}
