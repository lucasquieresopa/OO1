package ejercicio15.ejercicio15;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TestReserva {
	private Reserva r1, r2;
	LocalDate f1 = LocalDate.of(2000, 1, 1);
	LocalDate f2 = LocalDate.of(2003, 1, 1);
	LocalDate f3 = LocalDate.of(1998, 1, 1);
	LocalDate f4 = LocalDate.of(2005, 1, 1);
	LocalDate f5 = LocalDate.of(2001, 1, 1);
	
	
	
	@BeforeEach
	public void setUp() {
		r1 = new Reserva(new Propiedad(), 
						new DateLapse(LocalDate.of(1999, 7, 26), LocalDate.of(2002, 2, 9)), 
						new Usuario());
		r2 = new Reserva(new Propiedad("nombre1", "descripcion1", 100.0,
				"direccion1", new Usuario()),
						new DateLapse(LocalDate.of(2000, 1, 5), LocalDate.of(2000, 1, 15)),
						new Usuario());
	}
	
	@Test
	public void TestFechasValidasParaReservas() {
		assertTrue(r1.periodoIntercede(new DateLapse(f1, f2)));
		assertTrue(r1.periodoIntercede(new DateLapse(f3, f1)));
		assertTrue(r1.periodoIntercede(new DateLapse(f3, f2)));
		assertFalse(r1.periodoIntercede(new DateLapse(f2, f4)));
	}
	
	@Test
	public void TestNochesEntrePeriodo() {
		assertEquals(5, r2.nochesEntrePeriodos(new DateLapse(LocalDate.of(2000, 1, 10), LocalDate.of(2000, 1, 20))));
		assertEquals(5, r2.nochesEntrePeriodos(new DateLapse(LocalDate.of(2000, 1, 1), LocalDate.of(2000, 1, 10))));
		assertEquals(2, r2.nochesEntrePeriodos(new DateLapse(LocalDate.of(2000, 1, 10), LocalDate.of(2000, 1, 12))));
	}

}
