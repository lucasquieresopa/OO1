package ejercicio15.ejercicio15;

import java.time.LocalDate;

public class Reserva {
	private Propiedad propiedad;
	private DateLapse periodoDeReserva;
	private Usuario inquilino;
	
	public Reserva(Propiedad prop, DateLapse periodo, Usuario inquilino) {
		this.propiedad=prop;
		this.periodoDeReserva=periodo;
		this.inquilino=inquilino;
	}
	
	public Double calcularPrecioEntrePeriodo(DateLapse periodo1) {
		return this.propiedad.getPrecioPorNoche() * this.nochesEntrePeriodos(periodo1);
	}
	
	public Double calcularPrecioDeReserva() {
		return this.propiedad.getPrecioPorNoche() * this.periodoDeReserva.sizeInDays();
	}
	
	public DateLapse devolverPeriodoDeReserva() {
		return this.periodoDeReserva;
	}
	
	public Boolean periodoIntercede(DateLapse periodoAComprobar) {
		//metodo que devuelve true si el periodo recibido está
		//entre el periodo de reserva y false si no
		//evalua si la fecha de inicio o fin de periodoAComprobar está entre periodoDeReserva
		//y si el periodoDeReserva está contenido en periodoAComprobar 
		return this.periodoDeReserva.includesDate(periodoAComprobar.getFrom()) 
				|| this.periodoDeReserva.includesDate(periodoAComprobar.getTo())
				|| (periodoAComprobar.includesDate(this.periodoDeReserva.getFrom()) 
					&& periodoAComprobar.includesDate(this.periodoDeReserva.getTo())); 
	}
	
	public LocalDate getFechaInicio() {
		return this.periodoDeReserva.getFrom();
	}
	
	
	public int nochesEntrePeriodos(DateLapse periodo1) {
		//Es una interseccion de conjuntos
		//5 CASOS
		//1: periodo1 adentro de periodo2
		//2: periodo1.from adentro y periodo1.to afuera (de periodo2)
		//3: periodo1.from afuera y periodo1.to adentro (de periodo2)
		//4: periodo2 adentro de periodo1
		//5: periodo1 y periodo dos no se interceden
		DateLapse periodo2 = this.periodoDeReserva;
		int diasCompartidos = 0;
		if((periodo1.includesDate(periodo2.getFrom())
				|| periodo1.includesDate(periodo2.getTo()))
		|| (periodo2.includesDate(periodo1.getFrom())
				|| periodo2.includesDate(periodo1.getTo()))){
			//si se cumple que tienen interseccion
			
			if(periodo1.includesDate(periodo2.getFrom())
					&& (periodo1.includesDate(periodo2.getTo()))){
				//caso 1
				diasCompartidos = periodo1.sizeInDays() - periodo2.sizeInDays();
			}
			else {
				if((periodo2.includesDate(periodo1.getFrom()))
						&& (periodo2.includesDate(periodo1.getTo()))){
					//caso 4
					diasCompartidos = periodo2.sizeInDays() - periodo1.sizeInDays();
				}
				else {
					if(periodo1.includesDate(periodo2.getFrom())) {
						//caso 2
						diasCompartidos = new DateLapse(periodo2.getFrom(), periodo1.getTo()).sizeInDays();
					}
					else {
						diasCompartidos = new DateLapse(periodo1.getFrom(), periodo2.getTo()).sizeInDays();
					}
				}	
			}
		}
		return diasCompartidos;
		
	}
	
	public void eliminarReserva() {
		if(this.getFechaInicio().isAfter(LocalDate.now())) {
			this.propiedad.eliminarReserva(this);;
		}
	}
}
