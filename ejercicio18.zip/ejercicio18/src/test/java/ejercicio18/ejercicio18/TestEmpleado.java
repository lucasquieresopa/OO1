package ejercicio18.ejercicio18;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TestEmpleado {
	private Empresa empresa;
	private Empleado emp1, emp2;
	private Contrato c1;
	
	@BeforeEach
	public void setUp() {
	this.empresa = new Empresa();
	//emp1 posee contrato por horas
	this.emp1 = new Empleado("Pablo", "Gonzalez", "0123456",
			LocalDate.of(1980, 1, 1), true, true, LocalDate.of(2005, 1, 1));

	
	
	this.emp1 = new Empleado("Pedro", "Gomez", "23456", LocalDate.of(2000, 1, 1),
			true, true, LocalDate.of(2017, 1, 1));
	
	
	
	}
	@Test
	public void testContratoVigente1() {
		//le agrego un contrato a cada uno para ver si el metodo me devulve algo
		this.empresa.cargarContratoDeEmpleado(this.emp2, LocalDate.of(2017, 1, 1), 
				100.0, 45, LocalDate.of(2030, 1, 1));
		Contrato c1 = new PorHoras(this.emp1, LocalDate.of(2005, 1, 1),
				200.0, 50, LocalDate.of(2025, 1, 1));
		assertEquals(c1, this.emp1.obtenerContratoVigente());
		
		this.empresa.cargarContratoDeEmpleado(this.emp1, LocalDate.of(2005, 1, 1),
				200.0, 50, LocalDate.of(2025, 1, 1));
		Contrato c2 = new DePlanta(this.emp2, LocalDate.of(2017, 1, 1), 
			2000.0, 200.0, 300.0);
		assertEquals(c2, this.emp2.obtenerContratoVigente());
	}
	
	@Test
	public void testContratoVigente2() {
		//agrego varios contratos a un empleado y me deberia devolver el correcto
		Contrato correcto = new PorHoras(this.emp1, LocalDate.of(2019, 1, 1), null, null, LocalDate.of(2024, 1, 1));
		
		this.empresa.cargarContratoDeEmpleado(this.emp1, LocalDate.of(2002, 1, 1), null, null, LocalDate.of(2008, 1, 1));
		this.empresa.cargarContratoDeEmpleado(this.emp1, LocalDate.of(2012, 1, 1), null, null, LocalDate.of(2016, 1, 1));
		this.empresa.cargarContratoDeEmpleado(this.emp1, LocalDate.of(2019, 1, 1), null, null, LocalDate.of(2024, 1, 1));
		
		this.empresa.cargarContratoDeEmpleado(this.emp2, LocalDate.of(2002, 1, 1), 0.0, 0.0, 0.0);
		this.empresa.cargarContratoDeEmpleado(this.emp2, LocalDate.of(2012, 1, 1), null, null, LocalDate.of(2016, 1, 1));
		this.empresa.cargarContratoDeEmpleado(this.emp2, LocalDate.of(2019, 1, 1), null, null, LocalDate.of(2024, 1, 1));
	}
	
	@Test
	public void testReciboDeEmpleado() {
		assertEquals(17, this.emp1.calcularAntiguedad());
		assertEquals(((200.0 * 50.0) * 1.7), this.emp1.generarReciboDeEmpleado().getMontoTotal());
		
		assertEquals(5, this.emp2.calcularAntiguedad());
		assertEquals((2000.0 + 200.0 + 300.0), this.emp2.generarReciboDeEmpleado().getMontoTotal());
	
	}
}

//problemas con metodo obtenerContratoVigente
