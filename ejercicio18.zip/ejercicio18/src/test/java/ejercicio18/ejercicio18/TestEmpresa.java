package ejercicio18.ejercicio18;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TestEmpresa {
	private Empresa empresa;
	private Empleado emp1, emp2, emp3;
	
	@BeforeEach
	public void setUp() {
		this.empresa = new Empresa();
		//emp1 posee contrato por horas
		emp1 = this.empresa.darDeAltaEmpleado("Pablo", "Gonzalez", "0123456",
				LocalDate.of(1980, 1, 1), true, true, LocalDate.of(2005, 1, 1));
		emp2 = this.empresa.darDeAltaEmpleado("Pedro", "Gomez", "23456", LocalDate.of(2000, 1, 1),
				true, true, LocalDate.of(2017, 1, 1));
		emp3 = this.empresa.darDeAltaEmpleado("Leo", "Lopez", "54321", LocalDate.of(1990, 1, 1),
				true, true, LocalDate.of(2020, 1, 1));
		
		
		
		}
	
	@Test
	public void testBuscarEmpleadoPorCuil() {
		assertNull(this.empresa.buscarEmpleado("111111"));
		assertTrue(this.empresa.buscarEmpleado("0123456").getNombre().equals("Pablo"));
	}
	
	@Test
	public void testBorrarEmpleadoPorCuil() {
		this.empresa.darDeBajaEmpleado("23456");
		assertEquals(2, this.empresa.getEmpleados().size());
	}
	
	@Test
	public void testCargarContratoPorHoras() {
		//resolver problema con contrato vigente
		
		//agrego un contrato
		//chequeo que hay 1 contrato
		//agrego otro contrato
		//chequeo que sigue habiendo 1
		this.empresa.cargarContratoDeEmpleado(emp1, null, null, null, LocalDate.of(2024, 1, 1));
		assertEquals(1, emp1.getContratos().size());
		assertEquals(new PorHoras(emp1, null, null, null, LocalDate.of(2024, 1, 1)), emp1.getContratos().size());
		this.empresa.cargarContratoDeEmpleado(emp1, null, null, null, LocalDate.of(2027, 1, 1));
		assertEquals(1, emp1.getContratos().size());
		assertEquals(new PorHoras(emp1, null, null, null, LocalDate.of(2024, 1, 1)), emp1.getContratos().size());
	}
	
	@Test
	public void testCargarContratoPorHoras2() {
		//resolver problema con contrato vigente
		
		//agrego un contrato
		//chequeo que hay 1 contrato
		//agrego otro contrato
		//chequeo que sigue habiendo 1 y que es el nuevo
		this.empresa.cargarContratoDeEmpleado(emp1, null, null, null, LocalDate.of(2000, 1, 1));
		assertEquals(1, emp1.getContratos().size());
		assertEquals(new PorHoras(emp1, null, null, null, LocalDate.of(2024, 1, 1)), emp1.getContratos().size());
		this.empresa.cargarContratoDeEmpleado(emp1, null, null, null, LocalDate.of(2027, 1, 1));
		assertEquals(1, emp1.getContratos().size());
		assertEquals(new PorHoras(emp1, null, null, null, LocalDate.of(2027, 1, 1)), emp1.getContratos().size());
	}
	
	@Test
	public void testCargarContratoDePlanta() {
		//agrego contrato por horas vencido y luego uno de planta que deberia quedar como vigente
		this.empresa.cargarContratoDeEmpleado(emp1, null, null, null, LocalDate.of(2000, 1, 1));
		assertEquals(1, emp1.getContratos().size());
		assertEquals(new PorHoras(emp1, null, null, null, LocalDate.of(2024, 1, 1)), emp1.getContratos().size());
		this.empresa.cargarContratoDeEmpleado(emp1, LocalDate.of(2024, 1, 1), 0.0, 0.0, 0.0);
		assertEquals(1, emp1.getContratos().size());
		assertEquals(new DePlanta(emp1, LocalDate.of(2024, 1, 1), 0.0, 0.0, 0.0), emp1.getContratos().get(1));
	}
	
	@Test
	public void testEmpleadosConContratoVencido() {
		this.empresa.cargarContratoDeEmpleado(emp1, null, null, null, LocalDate.of(2000, 1, 1));
		this.empresa.cargarContratoDeEmpleado(emp2, null, null, null, LocalDate.of(2025, 1, 1));
		assertTrue(this.empresa.empleadosConContratoVencido().contains(emp1));
		assertFalse(this.empresa.empleadosConContratoVencido().contains(emp2));
	}
	
	@Test 
	public void testRecibos() {
		//emp1 tiene contrato vencido, emp2 y emp3 activos
		this.empresa.cargarContratoDeEmpleado(emp1, null, null, null, LocalDate.of(2000, 1, 1));
		this.empresa.cargarContratoDeEmpleado(emp2, null, null, null, LocalDate.of(2025, 1, 1));
		this.empresa.cargarContratoDeEmpleado(emp3, null, null, null, LocalDate.of(2030, 1, 1));
		assertEquals(2, this.empresa.generarRecibosDeCobro().size());
	
	}
	
	
}
