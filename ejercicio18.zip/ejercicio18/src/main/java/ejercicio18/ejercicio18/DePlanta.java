package ejercicio18.ejercicio18;

import java.time.LocalDate;

public class DePlanta extends Contrato{

	private Double sueldoMensual;
	private Double montoPorConyugeACargo;
	private Double montoPorHijosACargo;
	
	public DePlanta(Empleado empleado, LocalDate fechaInicio, 
			Double sueldoMensual, Double montoPorConyugeACargo, 
			Double montoPorHijosACargo) {
		super(empleado, fechaInicio);
		this.sueldoMensual = sueldoMensual;
		this.montoPorConyugeACargo = montoPorConyugeACargo;
		this.montoPorHijosACargo = montoPorHijosACargo;
	}
	
	public Double calcularMonto() {
		Double monto = sueldoMensual;
		if(super.tieneConyugeACargo()) {
			monto = monto + this.montoPorConyugeACargo;
		}
		if(super.tieneHijoACargo()) {
			monto = monto + this.montoPorHijosACargo;
		}
		return monto;
		
	}
	
	public Boolean estaVencido() {
		//el contrato nunca esta vencido puesto que es permanente
		return false;
	}
}
