package ejercicio18.ejercicio18;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Empresa {

	private ArrayList<Empleado> nominaDeEmpleados;
	
	public Empresa() {
		this.nominaDeEmpleados = new ArrayList<Empleado>();
	}
	
	public Empleado darDeAltaEmpleado(String nombre, String apellido, String cuil,
			LocalDate fechaDeNacimiento, Boolean conyugeACargo, 
			Boolean hijoACargo, LocalDate fechaInicio) {
		//fecha de inicio puede no estar e inicializarse en el constructor
		//como LocalDate.now()
		Empleado nuevoEmpleado = new Empleado(nombre, apellido, cuil, 
				fechaDeNacimiento, conyugeACargo, hijoACargo, fechaInicio);
		this.nominaDeEmpleados.add(nuevoEmpleado);
		return nuevoEmpleado;
	}
	
	public Empleado buscarEmpleado(String cuil) {
		return this.nominaDeEmpleados.stream()
				.filter(empleado -> empleado.getCuil().equals(cuil))
				.findAny().orElse(null);
	}
	
	public void darDeBajaEmpleado(String cuil) {
		Empleado empleadoAQuitar = this.nominaDeEmpleados.stream()
				.filter(empleado -> empleado.getCuil().equals(cuil))
				.findAny().orElse(null);
		if(!empleadoAQuitar.equals(null)) {
			this.nominaDeEmpleados.remove(empleadoAQuitar);
		}
	}
	
	public void cargarContratoDeEmpleado(Empleado empleado, LocalDate fechaDeInicio,
			Double valorHora, Integer horasPorMes, LocalDate fechaDeFin) {
		empleado.agregarContratoPorHoras(empleado, fechaDeInicio, valorHora, 
				horasPorMes, fechaDeFin);
		
	}
	
	public void cargarContratoDeEmpleado(Empleado empleado, LocalDate fechaInicio,
			Double sueldoMensual, Double montoPorConyugeACargo, Double montoPorHijoACargo) {
		empleado.agregarContratoDePlanta(empleado, fechaInicio, sueldoMensual, 
				montoPorConyugeACargo, montoPorHijoACargo);
	}
	
	public List<Empleado> empleadosConContratoVencido(){
		//dudas con enunciado y tipos de contrato. Pendiente a resolver
		return this.nominaDeEmpleados.stream()
				.filter(empleado -> empleado.contratoVigenteVencido() == false)
				.collect(Collectors.toList());
	}
	
	public List<Recibo> generarRecibosDeCobro() {
		return this.nominaDeEmpleados.stream() 
				.filter(empleado -> empleado.contratoVigenteVencido() == false)
				.map(empleado -> empleado.generarReciboDeEmpleado())
				.collect(Collectors.toList());
	}
	
	public List<Empleado> getEmpleados(){
		return this.nominaDeEmpleados;
	}
}


/*DUDAS:

Como modelar los contratos.
¿Es lo mismo un contrato activo que uno vigente?
¿Un contrato permanente se refiere a uno de planta?
¿Un empleado con contrato por horas debería tener una lista de contratos activos?
Si llega un contrato y el actual esta vencido lo actualizo con el nuevo, pero ¿si no esta vencido?


Esto es lo que entendi: tengo una lista de contratos del empleado. Si llega un contrato,
y aun hay uno vigente (no vencido), ese contrato se descarta. Si llega un contrato y
el actual esta vencido, se agrega el contrato a la lista (solo se agregará si el
contrato actual es por horas, debido a que si es de planta no puede estar vencido)
Para hallar el contrato actual (en ambos tipos de contrato), debo encontrar el contrato 
con fecha de inicio mas cercano a "hoy". 


¿El calculo del monto y antiguedad del recibo deberia hacerlo Recibo? No estoy seguro
porque el monto y la antiguedad son datos que se pueden usar para otras cosas ademas
de para generar un recibo


//problemas con metodo obtenerContratoVigente


//DUDA UML: agregar getters y setters??
 */
