package ejercicio18.ejercicio18;

import java.time.LocalDate;

public class PorHoras extends Contrato{

	private Double valorHora;
	private Integer horasPorMes;
	private LocalDate fechaFin;
	
	public PorHoras(Empleado empleado, LocalDate fechaInicio, Double valorHora, 
			Integer horasPorMes, LocalDate fechaFin) {
		super(empleado, fechaInicio);
		this.valorHora = valorHora;
		this.horasPorMes = horasPorMes;
		this.fechaFin = fechaFin;
	}
	
	public Double calcularMonto() {
		return this.valorHora * this.horasPorMes;
	}
	
	public Boolean estaVencido() {
		//determina que esta vencido si la fecha de final < fecha actual
		return this.fechaFin.isBefore(LocalDate.now());
	}
}
