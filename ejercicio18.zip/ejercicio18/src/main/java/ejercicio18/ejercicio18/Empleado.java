package ejercicio18.ejercicio18;

import java.sql.Date;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

public class Empleado {

	private String nombre;
	private String apellido;
	private String cuil;
	private LocalDate fechaDeNacimiento;
	private Boolean tieneConyugeACargo;
	private Boolean tieneHijoACargo;
	private LocalDate fechaDeInicio;
	private ArrayList<Contrato> contratos;
	
	public Empleado(String nombre, String apellido, String cuil,
			LocalDate fechaDeNacimiento, Boolean conyugeACargo, Boolean hijoACargo,
			LocalDate fechaInicio) {
		this.nombre = nombre;
		this.apellido = apellido;
		this.cuil = cuil;
		this.fechaDeNacimiento = fechaDeNacimiento;
		this.tieneConyugeACargo = conyugeACargo;
		this.tieneHijoACargo = hijoACargo;
		this.fechaDeInicio = fechaInicio;
		this.contratos = new ArrayList<Contrato>();
	}
	
	public Recibo generarReciboDeEmpleado() {
		//Como pido calcularMonto si un tipo de contrato necesita parametros
		//y el otro no??
		Double monto = this.obtenerContratoVigente().calcularMonto() + 
				this.montoPorAntiguedad(this.obtenerContratoVigente().calcularMonto());
		return new Recibo(this.nombre, this.apellido, this.cuil,
				this.calcularAntiguedad(), monto);
	}
	
	public Double montoPorAntiguedad(Double monto) {
		Integer antiguedad = this.calcularAntiguedad();
		if(antiguedad > 19) {
			return monto * 1;
		}
		else {
			if(antiguedad > 14) {
				return monto * 0.7;
			}
			else {
				if(antiguedad > 9) {
					return monto * 0.5;
				}
				else {
					if(antiguedad > 4) {
						return monto *0.3;
					}
					else return 0.0;
				}
			}
		}
	}
	
	public Integer calcularAntiguedad() {
		LocalDate date1 = this.fechaDeInicio;
		LocalDate date2 = LocalDate.now();
		Period period = date1.until(date2);
		return period.getYears();
		//return (int) (new Calendar(this.fechaDeInicio) - new GregorianCalendar().setTime(new Date()))
	}
	
	public void agregarContratoPorHoras(Empleado empleado, LocalDate fechaDeInicio,
			Double valorHora, Integer horasPorMes, LocalDate fechaDeFin) {
		//guarda el contrato recibido en la lista de contratos del
		//empleado si el contrato vigente no esta vencido
		if(!this.obtenerContratoVigente().estaVencido()) {
			this.contratos.add(new PorHoras(empleado, fechaDeInicio, valorHora, 
				horasPorMes, fechaDeFin));
		}
	}
	
	public void agregarContratoDePlanta(Empleado empleado, LocalDate fechaInicio,
			Double sueldoMensual, Double montoPorConyugeACargo, Double montoPorHijoACargo) {
		//guarda el contrato recibido en la lista de contratos del
		//empleado si el contrato vigente no esta vencido
		if(!this.obtenerContratoVigente().estaVencido()) {
			this.contratos.add(new DePlanta(empleado, fechaInicio, sueldoMensual, 
					montoPorConyugeACargo, montoPorHijoACargo));
		}
	}
	
	public Contrato obtenerContratoVigente() {
		//metodo no funciona bien en tests
		return this.contratos.stream()
				.max((contrato1, contrato2) -> contrato1.getFechaInicio().compareTo(contrato2.getFechaInicio())) 
				.orElse(null);
	}
	
	public Boolean contratoVigenteVencido() {
		return this.obtenerContratoVigente().estaVencido();
	}
	
	public String getCuil() {
		return this.cuil;
	}
	
	public Boolean tieneConyugeACargo() {
		return this.tieneConyugeACargo;
	}
	public Boolean tieneHijoACargo() {
		return this.tieneHijoACargo;
	}
	public String getNombre() {
		return this.nombre;
	}
	public List<Contrato> getContratos(){
		return this.contratos;
	}
}
