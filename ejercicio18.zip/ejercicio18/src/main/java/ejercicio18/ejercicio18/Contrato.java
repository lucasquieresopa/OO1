package ejercicio18.ejercicio18;

import java.time.LocalDate;

public abstract class Contrato {

	private LocalDate fechaInicio;
	private Empleado empleado;
	
	public abstract Double calcularMonto();
	
	public Contrato(Empleado empleado, LocalDate fechaInicio) {
		this.fechaInicio = fechaInicio;
		this.empleado = empleado;
	}
	
	public abstract Boolean estaVencido();
	
	public Boolean tieneConyugeACargo() {
		return this.empleado.tieneConyugeACargo();
	}
	
	public Boolean tieneHijoACargo() {
		return this.empleado.tieneHijoACargo();
	}
	
	public LocalDate getFechaInicio() {
		return this.fechaInicio;
	}
}
