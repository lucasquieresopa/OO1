package ejercicio18.ejercicio18;

import java.time.LocalDate;

public class Recibo {

	private String nombre;
	private String apellido;
	private String cuil;
	private Integer antiguedad;
	private LocalDate fechaDeGeneracion;
	private Double montoTotal;
	
	public Recibo(String nombre, String apellido, String cuil,
			Integer antiguedad, Double montoTotal) {
		this.nombre = nombre;
		this.apellido = apellido;
		this.cuil = cuil;
		this.antiguedad = antiguedad;
		this.fechaDeGeneracion = LocalDate.now();
		this.montoTotal = montoTotal;
	}
	
	public Double getMontoTotal() {
		return this.montoTotal;
	}
	
}
