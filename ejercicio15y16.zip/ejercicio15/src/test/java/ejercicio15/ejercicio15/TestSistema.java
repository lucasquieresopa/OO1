package ejercicio15.ejercicio15;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TestSistema {
	private Propiedad p1, p2, p3, p4;
	private Usuario u1;
	private Sistema sis;
	private Reserva r1, r2, r3, r4;
	private LocalDate f1 = LocalDate.of(2000, 1, 15);
	private LocalDate f2 = LocalDate.of(2003, 1, 1);
	private LocalDate f3 = LocalDate.of(1998, 1, 1);
	private LocalDate f4 = LocalDate.of(2005, 1, 1);
	private LocalDate f5 = LocalDate.of(2006, 1, 1);
	private PoliticaDeCancelacion politica;
	
	@BeforeEach
	public void setUp() {
		sis = new Sistema ();
		this.u1 = new Usuario();
		this.p1 = sis.registrarPropiedadEnAlquiler("nombre1", "descripcion1", 100.0,
				"direccion1", this.u1, this.politica = new Flexible() );
		this.p2 = sis.registrarPropiedadEnAlquiler("nombre2", "descripcion2", 200.0,
				"direccion2", this.u1, this.politica = new Moderada() );
		this.p3 = sis.registrarPropiedadEnAlquiler("nombre3", "descripcion3", 300.0,
				"direccion3", this.u1, this.politica= new Estricta() );
		
		
	}
	@Test
	public void testAgregarReserva() {
		assertTrue(sis.obtenerReservasDeUsuario(u1).isEmpty());
		r1 = sis.agregarReserva(p1, new DateLapse(LocalDate.of(1999, 1, 1), LocalDate.of(2002, 1, 10)), u1);
		assertEquals(1, sis.obtenerReservasDeUsuario(u1).size());
		r2 = sis.agregarReserva(p1, new DateLapse(f1, f2), u1);
		assertEquals(1, sis.obtenerReservasDeUsuario(u1).size());
		r3 = sis.agregarReserva(p1, new DateLapse(f3, f1), u1);
		assertEquals(1, sis.obtenerReservasDeUsuario(u1).size());
		r4 = sis.agregarReserva(p1, new DateLapse(f2, f4), u1);
		assertEquals(2, sis.obtenerReservasDeUsuario(u1).size());
		assertTrue(sis.obtenerReservasDeUsuario(u1).contains(r1));
		assertTrue(sis.obtenerReservasDeUsuario(u1).contains(r4));
		assertFalse(sis.obtenerReservasDeUsuario(u1).contains(r3));

	}
	
	@Test
	public void testPropiedadesDisponiblesParaReserva() {
		DateLapse ff = new DateLapse(LocalDate.of(2000, 1, 1), LocalDate.of(2000, 1, 11));
		r1 = sis.agregarReserva(p1, ff, u1);
		r2 = sis.agregarReserva(p2, ff, u1);
		assertTrue(sis.devolverPropiedadesDisponiblesParaReserva(ff).contains(p3));
		assertFalse(sis.devolverPropiedadesDisponiblesParaReserva(ff).contains(p1));
		assertFalse(sis.devolverPropiedadesDisponiblesParaReserva(ff).contains(p2));
	}
	
	//problema con lista de propiedades guarda propiedades que no deberia
	
	@Test
	public void testReembolsos() {
		DateLapse ff = new DateLapse(LocalDate.of(2000, 1, 1), LocalDate.of(2000, 1, 11));
		r1 = sis.agregarReserva(p1, ff, u1);
		r2 = sis.agregarReserva(p2, ff, u1);
		r3 = sis.agregarReserva(p3, ff, u1);
		
		assertEquals(1000.0 , sis.calcularReembolsoDeReserva(r1, LocalDate.of(1999, 12, 31)));
		assertEquals(1000.0 , sis.calcularReembolsoDeReserva(r2, LocalDate.of(1999, 12, 31)));
		assertEquals(2000.0 , sis.calcularReembolsoDeReserva(r2, LocalDate.of(1999, 12, 20)));
		assertEquals(0.0 , sis.calcularReembolsoDeReserva(r3, LocalDate.of(1999, 12, 20)));
	}
	
	
}
