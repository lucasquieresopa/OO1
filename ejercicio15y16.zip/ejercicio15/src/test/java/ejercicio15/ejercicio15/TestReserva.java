package ejercicio15.ejercicio15;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TestReserva {
	private Reserva r1, r2, r3;
	private Sistema sis;
	LocalDate f1 = LocalDate.of(2000, 1, 1);
	LocalDate f2 = LocalDate.of(2003, 1, 1);
	LocalDate f3 = LocalDate.of(1998, 1, 1);
	LocalDate f4 = LocalDate.of(2005, 1, 1);
	LocalDate f5 = LocalDate.of(2001, 1, 1);
	
	LocalDate f6 = LocalDate.of(2000, 1, 1);
	LocalDate f7 = LocalDate.of(2000, 1, 9);
	LocalDate f8 = LocalDate.of(2000, 1, 12);
	LocalDate f9 = LocalDate.of(2000, 1, 21);
	LocalDate f10 = LocalDate.of(2000, 1, 27);
	LocalDate f11 = LocalDate.of(2000, 1, 15);
	private PoliticaDeCancelacion politica;
	
	
	@BeforeEach
	public void setUp() {
		this.politica = new Estricta();
		this.sis = new Sistema();
		this.r1 = sis.agregarReserva(new Propiedad(), 
						new DateLapse(LocalDate.of(1999, 7, 26), LocalDate.of(2002, 2, 9)), 
						new Usuario());
		this.r2 = sis.agregarReserva(new Propiedad("nombre1", "descripcion1", 100.0,
				"direccion1", new Usuario(), politica),
						new DateLapse(LocalDate.of(2000, 1, 5), LocalDate.of(2000, 1, 15)),
						new Usuario());
		this.r3 = sis.agregarReserva(new Propiedad(),
						new DateLapse(LocalDate.of(2000, 1, 10), LocalDate.of(2000, 1, 20)),
						new Usuario());
	}
	
	@Test
	public void testFechasValidasParaReservas() {
		assertFalse(r3.periodoIntercede(new DateLapse(f6, f7)));
		assertTrue(r3.periodoIntercede(new DateLapse(f6, f8)));
		assertTrue(r3.periodoIntercede(new DateLapse(f7, f10)));
		assertTrue(r3.periodoIntercede(new DateLapse(f8, f11)));
		assertTrue(r3.periodoIntercede(new DateLapse(f8, f10)));
		assertFalse(r3.periodoIntercede(new DateLapse(f9, f10)));
	}
	
	@Test
	public void testNochesEntrePeriodo() {
		assertEquals(2, r2.nochesEntrePeriodos(new DateLapse(LocalDate.of(2000, 1, 10), LocalDate.of(2000, 1, 12))));
		assertEquals(10, r2.nochesEntrePeriodos(new DateLapse(LocalDate.of(1999, 12, 10), LocalDate.of(2000, 1, 20))));
		assertEquals(5, r2.nochesEntrePeriodos(new DateLapse(LocalDate.of(2000, 1, 10), LocalDate.of(2000, 1, 20))));
		assertEquals(5, r2.nochesEntrePeriodos(new DateLapse(LocalDate.of(2000, 1, 1), LocalDate.of(2000, 1, 10))));
		assertEquals(0, r2.nochesEntrePeriodos(new DateLapse(LocalDate.of(2002, 1, 1), LocalDate.of(2003, 1, 10))));
		assertEquals(0, r2.nochesEntrePeriodos(new DateLapse(LocalDate.of(1950, 1, 1), LocalDate.of(1960, 1, 10))));
		
	}

}
