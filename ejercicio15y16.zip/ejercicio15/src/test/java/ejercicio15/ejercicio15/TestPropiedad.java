package ejercicio15.ejercicio15;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TestPropiedad {
	private Propiedad p1, p2;
	private Usuario u1;
	private Sistema sis;
	private Reserva r1, r2, r3;
	private PoliticaDeCancelacion politica;
	private LocalDate f1 = LocalDate.of(2000, 1, 1);
	private LocalDate f2 = LocalDate.of(2000, 1, 11);
	private LocalDate f3 = LocalDate.of(1999, 12, 15);
	private LocalDate f4 = LocalDate.of(2000, 1, 4);
	private LocalDate f5 = LocalDate.of(2000, 1, 8);
	private LocalDate f6 = LocalDate.of(2000, 1, 22);
	private LocalDate f7 = LocalDate.of(2001, 2, 10);
	private LocalDate f8 = LocalDate.of(2001, 1, 25);
	
	@BeforeEach
	public void SetUp() {
		this.u1 = new Usuario();
		this.sis = new Sistema();
		this.politica = new Estricta();
		this.p1 = new Propiedad("nombre1", "descripcion1", 100.0,
				"direccion1", this.u1, politica);
		this.p2 = new Propiedad("nombre2", "descripcion2", 300.0,
				"direccion2", this.u1, politica);
		
		r1 = sis.agregarReserva(p1, 
				new DateLapse(LocalDate.of(2000, 1, 2), LocalDate.of(2000, 1, 10)), 
				this.u1);
		r2 = sis.agregarReserva(p1, 
				new DateLapse(LocalDate.of(2001, 1, 20), LocalDate.of(2001, 1, 30)), 
				this.u1);
	}
	
	@Test
	public void testDisponibilidad() {
		assertFalse(p1.Disponibilidad(new DateLapse(f1, f2)));
		assertFalse(p1.Disponibilidad(new DateLapse(f1, f4)));
		assertFalse(p1.Disponibilidad(new DateLapse(f4, f5)));
		assertFalse(p1.Disponibilidad(new DateLapse(f5, f6)));
		assertTrue(p1.Disponibilidad(new DateLapse(f3, f1)));
		assertTrue(p1.Disponibilidad(new DateLapse(f2, f6)));
	}
	
	@Test
	public void testGananciasDeUnaPropiedadEntrePeriodo() {
		assertEquals(800.0, p1.getGananciasEntreFecha(new DateLapse(f3, f6)));
		assertEquals(1800.0, p1.getGananciasEntreFecha(new DateLapse(f3, f7)));
		assertEquals(600.0, p1.getGananciasEntreFecha(new DateLapse(f1, f5)));
		assertEquals(1300.0, p1.getGananciasEntreFecha(new DateLapse(f1, f8)));
		assertEquals(0.0, p1.getGananciasEntreFecha(new DateLapse(f3, f1)));
	}
}
