package ejercicio15.ejercicio15;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TestUsuario {
	private Propiedad p1, p2;
	private Usuario u1, u2;
	private Sistema sis;
	private Reserva r1, r2, r3;
	private LocalDate f1 = LocalDate.of(2000, 1, 1);
	private LocalDate f2 = LocalDate.of(2000, 1, 11);
	private LocalDate f3 = LocalDate.of(1999, 12, 15);
	private LocalDate f4 = LocalDate.of(2000, 1, 4);
	private LocalDate f5 = LocalDate.of(2000, 1, 8);
	private LocalDate f6 = LocalDate.of(2000, 1, 22);
	private LocalDate f7 = LocalDate.of(2001, 2, 10);
	private LocalDate f8 = LocalDate.of(2000, 1, 13);
	private LocalDate f9 = LocalDate.of(2001, 1, 25);
	private PoliticaDeCancelacion politica;
	
	@BeforeEach
	public void SetUp() {
		this.u1 = new Usuario();
		this.u2 = new Usuario();
		this.sis = new Sistema();
		this.politica = new Estricta();
		
		p1 = sis.registrarPropiedadEnAlquiler("nombre1", "descripcion1", 100.0,
				"direccion1", this.u1, politica);
		p2 = sis.registrarPropiedadEnAlquiler("nombre2", "descripcion2", 300.0,
				"direccion2", this.u1, politica);
		
		r1 = sis.agregarReserva(p1, 
				new DateLapse(LocalDate.of(2000, 1, 2), LocalDate.of(2000, 1, 10)), 
				this.u2); //8 dias
		r2 = sis.agregarReserva(p1, 
				new DateLapse(LocalDate.of(2001, 1, 20), LocalDate.of(2001, 1, 30)), 
				this.u2); //10 dias
		r3 = sis.agregarReserva(p2, 
				new DateLapse(LocalDate.of(2000, 1, 5), LocalDate.of(2000, 1, 15)), 
				this.u2); //10 dias
	}
	
	@Test
	public void testGananciasDeUnUsuarioEntrePeriodo() {
		assertEquals(3800.0, u1.calcularIngresosEntreFechas(new DateLapse(f3, f6)));
		assertEquals(4800.0, u1.calcularIngresosEntreFechas(new DateLapse(f3, f7)));
		assertEquals(3200.0, u1.calcularIngresosEntreFechas(new DateLapse(f1, f8)));
		assertEquals(4300.0, u1.calcularIngresosEntreFechas(new DateLapse(f1, f9)));
		assertEquals(1100.0, u1.calcularIngresosEntreFechas(new DateLapse(f8, f9)));
	}
}
