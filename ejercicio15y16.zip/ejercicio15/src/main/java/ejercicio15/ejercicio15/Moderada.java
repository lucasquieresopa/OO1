package ejercicio15.ejercicio15;

import java.time.LocalDate;

public class Moderada implements PoliticaDeCancelacion{


	public Double calcularReembolso(Double montoTotal, LocalDate fechaDeCancelacion, 
					LocalDate fechaDeInicioDeReserva) {
		if(fechaDeCancelacion.isBefore(fechaDeInicioDeReserva)) {
			int diasEntreFechas = new DateLapse(fechaDeCancelacion, fechaDeInicioDeReserva).sizeInDays();
			if(diasEntreFechas > 6){
				return montoTotal;
			}
			else {
				return montoTotal/2;
			}
		}
		else return 0.0;
	}

}
