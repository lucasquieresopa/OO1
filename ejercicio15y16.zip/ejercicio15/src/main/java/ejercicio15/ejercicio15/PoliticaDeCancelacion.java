package ejercicio15.ejercicio15;

import java.time.LocalDate;

public interface PoliticaDeCancelacion {

	public Double calcularReembolso(Double montoTotal, LocalDate fechaDeCancelacion, 
			LocalDate fechaDeInicioDeReseva);
}
