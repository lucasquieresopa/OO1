package ejercicio15.ejercicio15;

import java.time.LocalDate;

public class Flexible implements PoliticaDeCancelacion{

	public Double calcularReembolso(Double montoTotal, 
						LocalDate fechaDeCancelacion,
						LocalDate fechaDeInicioDeReserva) {
		if(fechaDeCancelacion.isBefore(fechaDeInicioDeReserva)) {
			return montoTotal;
		}
		else return 0.0;
	}

}
