package ejercicio15.ejercicio15;

import java.time.LocalDate;

public class Estricta implements PoliticaDeCancelacion{


	public Double calcularReembolso(Double montoTotal, LocalDate fechaDeCancelacion, LocalDate fechaDeInicioDeReseva) {
		return 0.0;
	}
}

	
