package ejercicio15.ejercicio15;

import java.time.LocalDate;

public interface DateLapseInterface {
	
	public boolean includesDate(LocalDate other);
	public LocalDate getFrom();
	public LocalDate getTo();
	public int sizeInDays();
}
