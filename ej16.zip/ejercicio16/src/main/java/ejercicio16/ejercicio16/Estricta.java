package ejercicio16.ejercicio16;

public class Estricta extends PoliticaDeCancelacion{

	public Double calcularReembolso() {
		
	}
}
