package ejercicio16.ejercicio16;

public abstract class PoliticaDeCancelacion {

	public abstract Double calcularReembolso();
}
