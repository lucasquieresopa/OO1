package ejercicio16.ejercicio16;

import java.util.ArrayList;

public class PropiedadConCancelacionEstricta extends Propiedad{

	public Double calcularReembolso() {
		
	}
	
	public PropiedadConCancelacionFlexible (String nombre, String descripcion,
			Double precioPorNoche, String direccion, Usuario propietario) {
		this.nombre=nombre;
		this.descripcion=descripcion;
		this.precioPorNoche=precioPorNoche;
		this.direccion=direccion;
		this.propietario=propietario;
		this.listaDeReservas = new ArrayList<Reserva>();
	}
}
