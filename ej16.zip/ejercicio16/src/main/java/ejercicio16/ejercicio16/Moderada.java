package ejercicio16.ejercicio16;

import java.time.LocalDate;

public class Moderada extends PoliticaDeCancelacion{

	public Double calcularReembolso(LocalDate fechaDeCancelacion) {
		return null
	}
}
