package ejercicio16.ejercicio16;

public class Flexible extends PoliticaDeCancelacion{

	public Double calcularReembolso() {
		
	}
}
