package ejercicio16.ejercicio16;

public class Politica {

}
