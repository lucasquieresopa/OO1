package ejercicio16.ejercicio16;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.stream.Stream;

public abstract class Propiedad {
	private String nombre;
	private String descripcion;
	private Double precioPorNoche;
	private String direccion;
	private Usuario propietario;
	private PoliticaDeCancelacion politica;
	private ArrayList<Reserva> listaDeReservas;
	
	public Double getPrecioPorNoche() {
		return this.precioPorNoche;
	}
	
	public Boolean Disponibilidad(DateLapse periodoAReservar) {
		//iterar sobre cada reserva y si la fecha de inicio o fin esta
		//entre la fecha de inicio y fin de la reserva se retorna Falso
		
		return !(this.listaDeReservas.stream()
				.anyMatch(reserva -> reserva.periodoIntercede(periodoAReservar).equals(true)));
	}
	
	public Propiedad(String nombre, String descripcion, Double precioPorNoche,
			String direccion, Usuario propietario, PoliticaDeCancelacion politica) {
		this.nombre=nombre;
		this.descripcion=descripcion;
		this.precioPorNoche=precioPorNoche;
		this.direccion=direccion;
		this.propietario=propietario;
		this.politica=politica;
		this.listaDeReservas = new ArrayList<Reserva>();
	}
	public Propiedad() {
		this.listaDeReservas = new ArrayList<Reserva>();
	}
	
	public void agregarReservaAPropiedad(Reserva nuevaReserva) {
		this.listaDeReservas.add(nuevaReserva);
	}
	
	public ArrayList<Reserva> getListaReservas(){
		return this.listaDeReservas;
	}
	
	public void eliminarReserva(Reserva reservaAEliminar) {
		this.listaDeReservas.remove(reservaAEliminar);

	}
	
	public Double getGananciasEntreFecha(DateLapse periodo) {
		return this.listaDeReservas.stream()
				.mapToDouble(reserva -> reserva.calcularPrecioEntrePeriodo(periodo))
				.sum();
	}
	
	public Double calcularReembolso(LocalDate fechaDeCancelacion) {
		return this.politica.calcularReembolso(fechaDeCancelacion);
	}

}
