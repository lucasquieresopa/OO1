package ejercicio17.ejercicio17;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;
import java.util.Calendar;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TestSistemaDeLlamadas {
	private Telefono t1, t2, t3;
	private Sistema sis;
	private Cliente c1, c2, c3;
	private Llamada l1, l2, l3, l4, l5, l6;
	private LocalDate f1 = LocalDate.of(1900, 1, 1);
	private LocalDate f2 = LocalDate.of(2020, 1, 1);
	
	@BeforeEach
	public void setUp() {
		this.sis = new Sistema();
		this.sis.agregarTelefono(t1);
		this.sis.agregarTelefono(t2);
		this.sis.agregarTelefono(t3);
		
		Calendar hora1 = Calendar.getInstance();
				hora1.set(Calendar.HOUR, 6);
		Calendar hora2 = Calendar.getInstance();
				hora2.set(Calendar.HOUR, 17);
		
		this.c1 = this.sis.darDeAltaClienteFisico(null, null, null);
		this.c2 = this.sis.darDeAltaClienteFisico(null, null, null);
		this.c3 = this.sis.darDeAltaClienteJuridico(null, null, null, null);
		
		
		this.l1 = this.sis.registrarLlamadaLocal(LocalDate.of(2001, 1, 1), 
				hora1, 10, t1, t3);
		this.l2 = this.sis.registrarLlamadaInterurbana(LocalDate.of(2000, 1, 1), 
				hora1, 5, t3, t2, 50.0);
		this.l3 = this.sis.registrarLlamadaInterurbana(LocalDate.of(2000, 1, 1), 
				hora1, 5, t1, t3, 200.0);
		this.l4 = this.sis.registrarLlamadaInterurbana(LocalDate.of(2000, 1, 1), 
				hora1, 5, t2, t3, 600.0);
		this.l5 = this.sis.registrarLlamadaInternacional(LocalDate.of(2002, 1, 1), 
				hora1, 1, t2, t1, null, null);
		this.l6 = this.sis.registrarLlamadaInternacional(LocalDate.of(2003, 1, 1), 
				hora2, 20, t3, t2, null, null);
	}
	
	@Test
	public void testCostos() {
		//c1 llamdas totales = 1 * 10 * 0,9 + 5 * 10 * 2,5 * 0,9
		assertEquals((1 * 10 * 0.9) + (5 * 10 * 2.5 * 0.9), sis.facturarLlamadas(c1, f1, f2));
	}
}
