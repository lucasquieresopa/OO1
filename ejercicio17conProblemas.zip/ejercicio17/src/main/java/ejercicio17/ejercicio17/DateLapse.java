package ejercicio17.ejercicio17;

import java.time.Duration;
import java.time.LocalDate;
import java.time.temporal.Temporal;

public class DateLapse implements DateLapseInterface{
	private LocalDate from;
	private LocalDate to;
	
	public DateLapse(LocalDate desde, LocalDate hasta) {
		this.from = desde;
		this.to = hasta;
	}
	
	public LocalDate getFrom() {
		return this.from;
	}
	public LocalDate getTo() {
		return this.to;
	}
	public int sizeInDays() {
		return (int) Duration.between((Temporal) this.from.atStartOfDay(), this.to.atStartOfDay()).toDays();
	}
	public boolean includesDate(LocalDate other) {
		return other.isAfter(this.from) && other.isBefore(this.to);
	}

}
