package ejercicio17.ejercicio17;

import java.time.LocalDate;
import java.util.Calendar;

public class Internacional extends Llamada{
	
	private String paisDeOrigen;
	private String paisDeDestino;
	private Double precioDiurno = 4.0;
	private Double precioNocturno = 3.0;
	
	public Double calcularCosto(Integer duracion, Cliente cliente) {
		int hora = super.getHora().get(Calendar.HOUR_OF_DAY);
		if(hora > 8 && hora < 20) {
			return this.precioDiurno * duracion * cliente.calcularDescuento(duracion * this.precioDiurno);
		}
		else return this.precioNocturno * duracion * cliente.calcularDescuento(duracion * this.precioNocturno);
	}
	
	public Internacional(LocalDate fechaDeComienzo, Calendar horaDeComienzo, Integer duracionEnMinutos,
			Telefono receptor, Telefono llamador, String paisDeOrigen, String paisDeDestino) {
		super(fechaDeComienzo, horaDeComienzo, receptor, llamador, duracionEnMinutos);
		this.paisDeOrigen=paisDeOrigen;
		this.paisDeDestino=paisDeDestino;
	}


}
