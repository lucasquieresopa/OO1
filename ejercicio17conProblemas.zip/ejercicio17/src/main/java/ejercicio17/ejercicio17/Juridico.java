package ejercicio17.ejercicio17;

public class Juridico extends Cliente{
	private String cuit;
	private String tipo;
	
	public Juridico(String nombre, String direccion, Telefono telefono,String tipo, String cuit) {
		super(nombre, direccion, telefono);
		
		this.cuit=cuit;
		this.tipo=tipo;
		
	}
	
	public Double calcularDescuento(Double montoTotal) {
		return 0.0;
	}
	
}
