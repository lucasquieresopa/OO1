package ejercicio17.ejercicio17;

import java.time.LocalDate;

public class Factura {
	
	private Cliente correspondienteDeLaFactura;
	private LocalDate fechaDeFacturacion;
	private DateLapse periodoDeFacturacion;
	private Double montoTotal;
	
	public Factura(Cliente cliente, LocalDate fechaInicio, LocalDate fechaFin, Double montoTotal) {
		this.correspondienteDeLaFactura = cliente;
		this.fechaDeFacturacion = LocalDate.now();
		this.periodoDeFacturacion = new DateLapse(fechaInicio, fechaFin);
		this.montoTotal = montoTotal;
		//this.montoTotal = calcularTotalDeLlamadas(cliente, this.periodoDeFacturacion, 
		//		this.fechaDeFacturacion);
	}
	
//	public Double calcularTotalDeLlamadas(Cliente cliente, 
//			DateLapse periodo, LocalDate fechaDeFacturacion) {
//		return cliente.calcularMontoDeLlamadas(periodo, fechaDeFacturacion);
//	}
}
