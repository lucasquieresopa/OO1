package ejercicio17.ejercicio17;

import java.time.LocalDate;
import java.util.Calendar;

public class Interurbana extends Llamada{
	
	private Double costoFijo = 5.0;
	private Double costoPorMinutoMenorA100 = 2.0;
	private Double costoPorMinutoE100y500 = 2.5;
	private Double costoPorMinutoMayorA500 = 3.0;
	private Double distanciaEnKm;
	
	public Interurbana(LocalDate fechaDeComienzo, Calendar horaDeComienzo, Integer duracionEnMinutos,
			Telefono receptor, Telefono llamador, Double distanciaEnKm) {
		super(fechaDeComienzo, horaDeComienzo, receptor, llamador, duracionEnMinutos);
		this.distanciaEnKm=distanciaEnKm;
	}
	
	public Double calcularCosto(Integer duracion, Cliente cliente) {
		if(this.distanciaEnKm < 100.0) {
			return this.costoFijo * this.costoPorMinutoMenorA100 * duracion 
					* cliente.calcularDescuento(this.costoFijo * this.costoPorMinutoMenorA100 * duracion);
		}
		else {
			if(this.distanciaEnKm > 500.0) {
				return this.costoFijo * this.costoPorMinutoMayorA500 * duracion 
						* cliente.calcularDescuento(this.costoFijo * this.costoPorMinutoMenorA100 * duracion);
			}
			else return this.costoFijo * this.costoPorMinutoE100y500 * duracion 
					* cliente.calcularDescuento(this.costoFijo * this.costoPorMinutoMenorA100 * duracion);
		}
	}

}
