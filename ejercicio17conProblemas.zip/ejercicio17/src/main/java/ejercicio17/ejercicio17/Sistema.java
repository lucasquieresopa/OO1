package ejercicio17.ejercicio17;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;

public class Sistema {
	
	private ArrayList<Telefono> telefonosDisponibles;
	//Telefono como objetos o lista de strings?
	private ArrayList<Llamada> registroDeLlamadas;
	
	public Sistema() {
		this.telefonosDisponibles = new ArrayList<Telefono>();
		this.registroDeLlamadas = new ArrayList<Llamada>();
	}
	
	public void agregarTelefono(Telefono telefono) {
		this.telefonosDisponibles.add(telefono);
	}
	
	public Cliente darDeAltaClienteFisico(String nombre, String direccion, String dni) {
		Cliente nuevoCliente = new Fisico(nombre, direccion, dni, this.telefonosDisponibles.get(0));
		this.telefonosDisponibles.remove(0);
		return nuevoCliente;
	}
	public Cliente darDeAltaClienteJuridico(String nombre, String direccion, String cuit, String tipo) {
		Cliente nuevoCliente = new Juridico(nombre, direccion, this.telefonosDisponibles.get(0), tipo, cuit);
		this.telefonosDisponibles.remove(0);
		return nuevoCliente;
	}
	
	public Llamada registrarLlamadaLocal(LocalDate fechaDeComienzo, Calendar horaDeComienzo,
			Integer duracionEnMinutos, Telefono llamador, Telefono receptor) {
		Llamada nuevaLlamada = new Local(fechaDeComienzo, horaDeComienzo, duracionEnMinutos, llamador, receptor);
		this.registroDeLlamadas.add(nuevaLlamada);
		return nuevaLlamada;
	}
	
	public Llamada registrarLlamadaInterurbana(LocalDate fechaDeComienzo, Calendar horaDeComienzo,
			Integer duracionEnMinutos, Telefono llamador, Telefono receptor, Double distanciaEnKm) {
		Llamada nuevaLlamada = new Interurbana(fechaDeComienzo, horaDeComienzo, duracionEnMinutos, 
				llamador, receptor, distanciaEnKm);
		this.registroDeLlamadas.add(nuevaLlamada);
		return nuevaLlamada;
	}
	
	
	
	public Llamada registrarLlamadaInternacional(LocalDate fechaDeComienzo, Calendar horaDeComienzo,
			Integer duracionEnMinutos, Telefono llamador, Telefono receptor, String paisDeOrigen,
			String paisDeDestino) {
		Llamada nuevaLlamada = new Internacional(fechaDeComienzo, horaDeComienzo, duracionEnMinutos, 
				llamador, receptor, paisDeOrigen, paisDeDestino);
		this.registroDeLlamadas.add(nuevaLlamada);
		return nuevaLlamada;
	}
	
	public Factura facturarLlamadas(Cliente cliente, LocalDate fechaInicio, LocalDate fechaFin) {
		Double montoTotal = this.registroDeLlamadas.stream()
				.filter(llamada -> llamada.getLlamador().equals(cliente.getTelefono()))
				.filter(llamada2 -> llamada2.saberSiLlamadaSeHallaEntrePeriodo(fechaInicio, fechaFin))
				.mapToDouble(llamada3 -> llamada3.calcularCosto(llamada3.getDuracion(), cliente))
				.sum();
		
		Factura nuevaFactura = new Factura(cliente, fechaInicio, fechaFin, montoTotal);
		
		return nuevaFactura;
	}
}
