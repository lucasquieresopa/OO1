package ejercicio17.ejercicio17;

import java.time.LocalDate;

public abstract class Cliente {
	
	private String nombre;
	private String direccion;
	private Telefono telefono;
	
	public Cliente(String nombre, String direccion, Telefono telefono) {
		this.nombre=nombre;
		this.direccion=direccion;
		this.telefono=telefono;
	}
	
	public Telefono getTelefono() {
		return this.telefono;
	}
	
	public abstract Double calcularDescuento(Double montoTotal); 
	//juridico tambien debe tener un metodo para calcularDescuento?
	
//	public Double calcularMontoDeLlamadas(DateLapse periodo, LocalDate fechaDeFacturacion) {
//		
//	}
}
