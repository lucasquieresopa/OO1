package ejercicio17.ejercicio17;

public class Fisico extends Cliente{

	private String dni;
	
	public Fisico(String nombre, String direccion, String dni, Telefono telefono) {
		super(nombre, direccion, telefono);
		this.dni=dni;
	}
	
	public Double calcularDescuento(Double montoTotal) {
		return montoTotal * 0.9;
	}
}
