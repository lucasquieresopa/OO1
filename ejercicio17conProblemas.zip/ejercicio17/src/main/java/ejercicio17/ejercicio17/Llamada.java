package ejercicio17.ejercicio17;

import java.time.LocalDate;
import java.util.Calendar;

public abstract class Llamada {

	private LocalDate fechaDeComienzo;
	private Calendar horaDeComienzo;
	private Telefono receptor;
	private Telefono llamador;
	private Integer duracionEnMinutos;
	
	public abstract Double calcularCosto(Integer duracion, Cliente cliente);
	
	public Llamada(LocalDate fechaDeComienzo, Calendar horaDeComienzo, Telefono receptor, 
			Telefono llamador, Integer duracionEnMinutos) {
		this.fechaDeComienzo=fechaDeComienzo;
		this.horaDeComienzo=horaDeComienzo;
		this.receptor=receptor;
		this.llamador=llamador;
		this.duracionEnMinutos=duracionEnMinutos;
	}
	
	//consultar si esta bien la manera en que estan planteados los constructores de las
	//3 subclases, usando super para los metodos de Llamada (superclase) y this para los de c/clase
	
	public Calendar getHora() {
		return this.horaDeComienzo;
	}
	
	public Telefono getLlamador() {
		return this.llamador;
	}
	
	public Integer getDuracion() {
		return this.duracionEnMinutos;
	}
	public Boolean saberSiLlamadaSeHallaEntrePeriodo(LocalDate fechaInicio, LocalDate fechaFin) {
		if((fechaInicio.isBefore(this.fechaDeComienzo)) && (fechaFin.isAfter(this.fechaDeComienzo))){
			return true;
		}
		else return false;
	}

}
