package ejercicio17.ejercicio17;

public class Telefono {
	
	private String numero;
	
	public Telefono(String numero) {
		this.numero=numero;
	}
}
