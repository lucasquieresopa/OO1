package ejercicio17.ejercicio17;

import java.time.LocalDate;
import java.util.Calendar;

public class Local extends Llamada{
	
	private Double costo = 1.0;
	
	public Double calcularCosto(Integer duracion, Cliente cliente) {
		return duracion * this.costo * cliente.calcularDescuento(duracion * this.costo);
	}
	public Local(LocalDate fechaDeComienzo, Calendar horaDeComienzo, Integer duracionEnMinutos,
			Telefono llamador, Telefono receptor) {
		super(fechaDeComienzo, horaDeComienzo, receptor, llamador, duracionEnMinutos);
				
	}
}
