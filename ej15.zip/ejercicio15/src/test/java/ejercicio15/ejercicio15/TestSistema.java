package ejercicio15.ejercicio15;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TestSistema {
	private Propiedad p1, p2, p3, p4;
	private Usuario u1;
	private Sistema sis;
	private LocalDate f1 = LocalDate.of(2000, 1, 15);
	private LocalDate f2 = LocalDate.of(2003, 1, 1);
	private LocalDate f3 = LocalDate.of(1998, 1, 1);
	private LocalDate f4 = LocalDate.of(2005, 1, 1);
	private LocalDate f5 = LocalDate.of(2006, 1, 1);
	
	@BeforeEach
	public void setUp() {
		sis = new Sistema ();
		this.u1 = sis.registrarUsuario(null, null, null);
		this.p1 = sis.registrarPropiedadEnAlquiler("nombre1", "descripcion1", 100.0,
				"direccion1", this.u1);
		this.p2 = sis.registrarPropiedadEnAlquiler("nombre2", "descripcion2", 200.0,
				"direccion2", this.u1);
		this.p3 = sis.registrarPropiedadEnAlquiler("nombre3", "descripcion3", 300.0,
				"direccion3", this.u1);
		
		
	}
	@Test
	public void testAgregarReserva() {
		assertTrue(sis.obtenerReservasDeUsuario(u1).isEmpty());
		sis.agregarReserva(p1, new DateLapse(LocalDate.of(1999, 1, 1), LocalDate.of(2002, 1, 10)), u1);
		assertEquals(1, sis.obtenerReservasDeUsuario(u1).size());
		sis.agregarReserva(p1, new DateLapse(f1, f2), u1);
		assertEquals(1, sis.obtenerReservasDeUsuario(u1).size());
		sis.agregarReserva(p1, new DateLapse(f3, f1), u1);
		assertEquals(1, sis.obtenerReservasDeUsuario(u1).size());
		sis.agregarReserva(p1, new DateLapse(f2, f4), u1);
		assertEquals(2, sis.obtenerReservasDeUsuario(u1).size());
		
		
		//Como identifico la propiedad a la que quiero hacerle una reserva???
	}
	
	@Test
	public void TestPropiedadesDisponiblesParaReserva() {
//		sis.agregarReserva(p1, new DateLapse(f1, f2), u1);
//		sis.agregarReserva(p2, new DateLapse(f1, f2), u1);
//		
//		assertEquals(p3, sis.devolverPropiedadesDisponiblesParaReserva(new DateLapse(f4, f5)));
	}
}
