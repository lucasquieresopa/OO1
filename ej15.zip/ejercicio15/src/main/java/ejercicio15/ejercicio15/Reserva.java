package ejercicio15.ejercicio15;

import java.time.LocalDate;

public class Reserva {
	private Propiedad propiedad;
	private DateLapse periodoDeReserva;
	private Usuario inquilino;
	
	public Reserva(Propiedad prop, DateLapse periodo, Usuario inquilino) {
		this.propiedad=prop;
		this.periodoDeReserva=periodo;
		this.inquilino=inquilino;
	}
	
	public Double calcularPrecioEntrePeriodo(DateLapse periodo1) {
		return this.propiedad.getPrecioPorNoche() * this.nochesEntrePeriodos(periodo1);
	}
	
	public Double calcularPrecioDeReserva() {
		return this.propiedad.getPrecioPorNoche() * this.periodoDeReserva.sizeInDays();
	}
	
	public DateLapse devolverPeriodoDeReserva() {
		return this.periodoDeReserva;
	}
	
	public Boolean periodoIntercede(DateLapse periodoAComprobar) {
		//metodo que devuelve true si el periodo recibido está
		//entre el periodo de reserva y false si no
		//evalua si la fecha de inicio o fin de periodoAComprobar está entre periodoDeReserva
		//y si el periodoDeReserva está contenido en periodoAComprobar 
		return this.periodoDeReserva.includesDate(periodoAComprobar.getFrom()) 
				|| this.periodoDeReserva.includesDate(periodoAComprobar.getTo())
				|| (periodoAComprobar.includesDate(this.periodoDeReserva.getFrom()) 
					&& periodoAComprobar.includesDate(this.periodoDeReserva.getTo())); 
	}
	
	public LocalDate getFechaInicio() {
		return this.periodoDeReserva.getFrom();
	}
	
	public int nochesEntrePeriodos(DateLapse periodo1) {
		//primero comprobar si no se cruzan. Si es que se cruzan, entonces
		//debo tomar cada caso, hallar la fecha From maxima e/los 2 y la
		//fecha To minima e/los 2
		DateLapse periodo2 = this.periodoDeReserva;
		if((periodo1.getFrom().isAfter(periodo2.getTo())) || (periodo1.getTo().isBefore(periodo2.getFrom()))){
			return 0;
		}
		else {
			LocalDate fechaInicio;
			LocalDate fechaFin;
			if(periodo1.getFrom().isAfter(periodo2.getFrom())) {
				fechaInicio = periodo1.getFrom();
			}
			else {
				fechaInicio = periodo2.getFrom();
			}
			if(periodo1.getTo().isBefore(periodo2.getTo())) {
				fechaFin = periodo1.getTo();
			}
			else {
				fechaFin = periodo2.getTo();
			}
			return new DateLapse(fechaInicio, fechaFin).sizeInDays();
		}
			
	}
	
	
	public void eliminarReserva() {
		if(this.getFechaInicio().isAfter(LocalDate.now())) {
			this.propiedad.eliminarReserva(this);;
		}
	}
}
