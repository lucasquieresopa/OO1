package ejercicio15.ejercicio15;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Sistema {
	private ArrayList<Usuario> listaDeUsuarios;
	private ArrayList<Propiedad> listaDePropiedades;
	
	public void registrarUsuario(String nombre, String direccion, String dni) {
		Usuario nuevoUsuario = new Usuario(nombre, direccion, dni);
		this.listaDeUsuarios.add(nuevoUsuario);
	}
	
	public void registrarPropiedadEnAlquiler(String nombre, String descripcion,
			Double precioPorNoche, String direccion, Usuario propietario) {
		Propiedad nuevaPropiedad = new Propiedad(nombre, descripcion, 
									precioPorNoche, direccion, propietario);
		this.listaDePropiedades.add(nuevaPropiedad);
		propietario.agregarPropiedad(nuevaPropiedad);
	}
	
	public List<Propiedad> devolverPropiedadesDisponiblesParaReserva(DateLapse periodo){
		return this.listaDePropiedades.stream()
				.filter(propiedad -> propiedad.Disponibilidad(periodo) == true)
				.collect(Collectors.toList());
	}
	
	public void agregarReserva(Propiedad propiedad, DateLapse periodo, Usuario inquilino) {
		Reserva nuevaReserva = new Reserva(propiedad, periodo, inquilino);
		if(propiedad.Disponibilidad(nuevaReserva.devolverPeriodoDeReserva())) {
			propiedad.agregarReservaAPropiedad(nuevaReserva);
			inquilino.agregarReservaAUsuario(nuevaReserva);
			return nuevaReserva;
		}
		return null;
	}
	
	public Double calcularPrecioDeReserva(Reserva reservaACalcular) {
		return reservaACalcular.calcularPrecioDeReserva();
	}
	
	public void eliminarReserva(Reserva reservaAEliminar) {
		reservaAEliminar.eliminarReserva();
	}
	
	public List<Reserva> obtenerReservasDeUsuario(Usuario usuario){
		return usuario.getReservas();
	}
	
	public Double calcularIngresos(Usuario usuario, DateLapse periodo) {
		return usuario.calcularIngresosEntreFechas(periodo);
	}
	
	public Sistema() {
		this.listaDePropiedades = new ArrayList<Propiedad>();
		this.listaDeUsuarios = new ArrayList<Usuario>();
	}

}
